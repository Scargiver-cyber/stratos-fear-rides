# Overview

**Stratos-FEAR Rides** is a retro-style, terminal-based space tourism simulator.

Core features:

- Shared fuel depot for all spacecraft
- Interactive fuel allocation and rebalancing
- Crew selection and reassignment between ships
- Mission planning and readiness checks
- Passenger booking
- Cinematic launch sequence with page breaks and terminal effects
